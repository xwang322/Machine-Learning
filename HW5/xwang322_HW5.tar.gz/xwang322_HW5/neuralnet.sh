#1/bin/bash
java -jar submission.jar $1 $2 $3 $4
